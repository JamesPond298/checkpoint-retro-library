from checkpoint_scanner.gui import main

main()


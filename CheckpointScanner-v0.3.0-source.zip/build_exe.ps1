$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectRoot

if (-not (Get-Command pyinstaller -ErrorAction SilentlyContinue)) {
    Write-Host "PyInstaller is not installed. Run: python -m pip install pyinstaller"
    exit 1
}

pyinstaller --noconfirm --clean --onefile --windowed `
    --name "Checkpoint-Scanner" `
    --paths $projectRoot `
    "run_checkpoint_scanner.pyw"

Write-Host "Built: $projectRoot\dist\Checkpoint-Scanner.exe"


from __future__ import annotations

import hashlib
import json
import os
import re
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

SCHEMA_FORMAT = "checkpoint-inventory"
SCHEMA_VERSION = 1
SCANNER_VERSION = "0.3.0"

PLATFORMS = {
    "NES": ({"nes", "fc", "famicom", "favorite nes"}, {".nes", ".zip"}),
    "SNES": ({"snes", "sfc", "supernintendo"}, {".sfc", ".smc", ".zip"}),
    "GB": ({"gb", "gameboy"}, {".gb", ".zip"}),
    "GBC": ({"gbc", "gameboycolor"}, {".gbc", ".zip"}),
    "GBA": ({"gba", "gameboyadvance"}, {".gba", ".zip"}),
    "N64": ({"n64", "nintendo64"}, {".z64", ".n64", ".v64", ".zip"}),
    "MASTER_SYSTEM": ({"mastersystem", "master system", "sms"}, {".sms", ".zip"}),
    "GENESIS": ({"genesis", "megadrive", "mega-drive", "md"}, {".md", ".gen", ".smd", ".bin", ".zip", ".cue"}),
    "SEGA_CD": ({"segacd", "sega cd", "megacd", "mega cd"}, {".cue", ".chd", ".iso", ".bin"}),
    "SATURN": ({"saturn", "ss"}, {".chd", ".cue", ".bin", ".iso"}),
    "DREAMCAST": ({"dreamcast", "dc"}, {".cdi", ".chd", ".gdi", ".cue", ".bin"}),
    "NDS": ({"nds", "ds", "nintendods"}, {".nds", ".zip"}),
    "3DS": ({"3ds", "n3ds", "nintendo3ds"}, {".3ds", ".cci", ".cxi"}),
    "ARCADE_CPS1": ({"cps1"}, {".zip"}),
    "ARCADE_CPS2": ({"cps2"}, {".zip"}),
    "ARCADE_CPS3": ({"cps3"}, {".zip"}),
    "ARCADE_FBNEO": ({"fbneo", "finalburnneo", "final burn neo"}, {".zip"}),
    "ARCADE_MAME": ({"mame", "arcade", "hbmame"}, {".zip", ".7z"}),
    "NEOGEO": ({"neogeo", "neo geo"}, {".zip"}),
    "NGP": ({"ngp", "neogeopocket", "neo geo pocket"}, {".ngp", ".ngc", ".zip"}),
    "OPENBOR": ({"openbor", "open beats of rage"}, {".pak"}),
    "MSX2": ({"msx2", "msx2+", "msx2plus"}, {".rom", ".dsk", ".cas", ".zip"}),
    "PCENGINE": ({"pcengine", "pc engine", "turbografx16", "turbografx-16"}, {".pce", ".zip"}),
    "WONDERSWAN_COLOR": ({"wswanc", "wonderswancolor", "wonderswan color"}, {".wsc", ".zip"}),
    "PS1": ({"psx", "ps1", "psone", "playstation"}, {".chd", ".cue", ".bin", ".pbp", ".iso", ".img", ".ccd", ".sub", ".mdf", ".mds", ".7z"}),
    "PS2": ({"ps2", "playstation2"}, {".iso", ".chd", ".cso", ".zip"}),
    "PS3": ({"ps3", "playstation3"}, {".iso", ".zip", ".pkg"}),
    "PSP": ({"psp", "playstationportable"}, {".iso", ".cso", ".chd"}),
    "WII_GC": ({"wii&ngc", "wii and ngc", "wii", "gamecube", "ngc", "gc"}, {".iso", ".rvz", ".wbfs", ".gcz", ".ciso", ".zip"}),
}

DISC_PLATFORMS = {"SEGA_CD", "SATURN", "DREAMCAST", "PS1", "PS2", "PS3", "PSP", "WII_GC"}
ARCHIVE_EXTENSIONS = {".zip", ".7z"}
DESCRIPTOR_EXTENSIONS = {".cue", ".ccd", ".mds", ".gdi"}

IGNORED_DIRS = {
    "bios", "system", "saves", "save", "savestates", "states", "artwork",
    "images", "covers", "screenshots", "manuals", "bezels", "themes", "config",
    "configs", "metadata", "cache", "videos", "video", "media",
    "system volume information", "lost.dir", "android", "dcim", "alarms",
    "audiobooks", "documents", "movies", "music", "notifications", "pictures",
    "podcasts", "recordings", "ringtones",
}

REGION_WORDS = {
    "usa": "USA", "us": "USA", "europe": "Europe", "eu": "Europe",
    "japan": "Japan", "jp": "Japan", "world": "World", "australia": "Australia",
}

REVIEW_TAGS = {"hack", "prototype", "proto", "beta", "demo", "translation", "homebrew", "unlicensed"}
DISC_RE = re.compile(r"(?i)(?:[\s._-]*[\[(]?(?:disc|disk|cd)\s*0*(\d+)[\])]?)")
TRACK_RE = re.compile(r"(?i)[\s._-]*(?:track|trk)\s*0*\d+")
BRACKET_RE = re.compile(r"\s*[\[(]([^\])]+)[\])]")
CATALOG_PREFIX_RE = re.compile(r"^\s*\d{3}[\s._-]+")


@dataclass
class Candidate:
    platform: str
    path: Path
    relative_path: str
    title: str
    identity_title: str
    region: str | None
    disc: int | None
    kind: str
    reasons: list[str] = field(default_factory=list)


class ScanCancelled(Exception):
    pass


def _compact(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.casefold())


ALIAS_TO_PLATFORM = {
    _compact(alias): platform
    for platform, (aliases, _extensions) in PLATFORMS.items()
    for alias in aliases
}


def platform_for_path(path: Path, root: Path) -> str | None:
    """Use the nearest recognized ancestor, including the selected directory."""
    try:
        parts = path.relative_to(root).parts[:-1]
    except ValueError:
        return None
    candidates = (root.name, *parts)
    for part in reversed(candidates):
        platform = ALIAS_TO_PLATFORM.get(_compact(part))
        if platform:
            return platform
    return None


def parse_name(stem: str) -> tuple[str, str, str | None, int | None, list[str]]:
    reasons: list[str] = []
    region = None
    disc_match = DISC_RE.search(stem)
    disc = int(disc_match.group(1)) if disc_match else None
    tags = [match.group(1).strip() for match in BRACKET_RE.finditer(stem)]
    for tag in tags:
        normalized = tag.casefold().strip()
        if normalized in REGION_WORDS and region is None:
            region = REGION_WORDS[normalized]
        if any(word in normalized for word in REVIEW_TAGS):
            reasons.append(f"Review filename tag: {tag}")
    title = CATALOG_PREFIX_RE.sub("", stem)
    title = DISC_RE.sub("", title)
    title = TRACK_RE.sub("", title)
    title = BRACKET_RE.sub("", title)
    title = re.sub(
        r"(?i)\b(?:rev(?:ision)?(?:\s+|[._-]+)[a-z0-9.]+|v(?:er(?:sion)?)?\s*\d+(?:\.\d+)*)\b",
        "",
        title,
    )
    title = re.sub(r"\s*[-_.]+\s*", " ", title)
    title = re.sub(r"\s+", " ", title).strip(" -_.") or stem
    identity = re.sub(r"[^a-z0-9]+", " ", title.casefold()).strip()
    return title, identity, region, disc, reasons


def _cue_references(path: Path) -> set[str]:
    refs: set[str] = set()
    try:
        text = path.read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return refs
    for match in re.finditer(r'(?im)^\s*FILE\s+(?:"([^"]+)"|(\S+))', text):
        refs.add(Path(match.group(1) or match.group(2)).name.casefold())
    return refs


def _descriptor_companions(path: Path) -> set[str]:
    """Return same-name files that belong to a disc descriptor."""
    ext = path.suffix.casefold()
    if ext == ".ccd":
        return {f"{path.stem}.img".casefold(), f"{path.stem}.sub".casefold()}
    if ext == ".mds":
        return {f"{path.stem}.mdf".casefold()}
    return set()


def _load_gamelist_titles(root: Path, issues: list[dict]) -> dict[Path, str]:
    """Read EmulationStation gamelist.xml names; ROM contents remain untouched."""
    titles: dict[Path, str] = {}
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs[:] = [d for d in dirs if d.casefold() not in IGNORED_DIRS and not Path(current, d).is_symlink()]
        names = {name.casefold(): name for name in files}
        actual = names.get("gamelist.xml")
        if not actual:
            continue
        xml_path = Path(current, actual)
        try:
            tree = ET.parse(xml_path)
            for game in tree.findall(".//game"):
                raw_path = (game.findtext("path") or "").strip()
                raw_name = (game.findtext("name") or "").strip()
                if not raw_path or not raw_name:
                    continue
                target = (xml_path.parent / raw_path).resolve()
                try:
                    target.relative_to(root)
                except ValueError:
                    continue
                titles[target] = raw_name
        except (OSError, ET.ParseError) as error:
            issues.append({"path": xml_path.relative_to(root).as_posix(), "message": f"Could not read gamelist metadata: {error}"})
    return titles


def scan_directory(
    root: str | Path,
    progress: Callable[[int, str], None] | None = None,
    cancelled: Callable[[], bool] | None = None,
) -> dict:
    root_path = Path(root).expanduser().resolve()
    if not root_path.is_dir():
        raise ValueError("The selected ROM directory does not exist or is not a directory.")

    candidates: list[Candidate] = []
    issues: list[dict] = []
    gamelist_titles = _load_gamelist_titles(root_path, issues)
    ignored = 0
    referenced_companions: set[tuple[Path, str]] = set()
    visited_files = 0

    def on_walk_error(error: OSError) -> None:
        issues.append({"path": str(getattr(error, "filename", "")), "message": str(error)})

    for current, dirs, files in os.walk(root_path, topdown=True, onerror=on_walk_error, followlinks=False):
        if cancelled and cancelled():
            raise ScanCancelled()
        dirs[:] = [d for d in dirs if d.casefold() not in IGNORED_DIRS and not Path(current, d).is_symlink()]
        current_path = Path(current)
        for filename in files:
            visited_files += 1
            if progress and visited_files % 25 == 0:
                progress(visited_files, str(current_path))
            path = current_path / filename
            if path.is_symlink():
                ignored += 1
                continue
            platform = platform_for_path(path, root_path)
            ext = path.suffix.casefold()
            if not platform:
                if any(ext in extensions for _aliases, extensions in PLATFORMS.values()):
                    title, _identity, _region, _disc, _reasons = parse_name(path.stem)
                    issues.append({
                        "path": path.relative_to(root_path).as_posix(),
                        "message": f"Supported-looking file '{title}' is not inside a recognized console folder.",
                    })
                else:
                    ignored += 1
                continue
            # Some cards store Sega CD beside Genesis cartridges. A disc
            # descriptor is enough to identify it without reading ROM data.
            if platform == "GENESIS" and ext in DESCRIPTOR_EXTENSIONS:
                platform = "SEGA_CD"
            if platform == "GBC" and ext == ".gb":
                platform = "GB"
            allowed = PLATFORMS[platform][1]
            if ext not in allowed:
                ignored += 1
                continue
            reasons: list[str] = []
            if ext in ARCHIVE_EXTENSIONS:
                reasons.append(f"{ext[1:].upper()} contents were not inspected; verify this archive contains one game.")
            if ext == ".cue":
                refs = _cue_references(path)
                referenced_companions.update((path.parent, ref) for ref in refs)
                if not refs:
                    reasons.append("CUE file has no readable track references.")
            if ext in DESCRIPTOR_EXTENSIONS:
                referenced_companions.update((path.parent, ref) for ref in _descriptor_companions(path))
            source_title = gamelist_titles.get(path.resolve(), path.stem)
            title, identity, region, disc, name_reasons = parse_name(source_title)
            reasons.extend(name_reasons)
            kind = "disc-descriptor" if ext in DESCRIPTOR_EXTENSIONS else "disc-image" if platform in DISC_PLATFORMS else "rom"
            candidates.append(Candidate(
                platform, path, path.relative_to(root_path).as_posix(), title,
                identity, region, disc, kind, reasons,
            ))

    # Files referenced by a disc descriptor are tracks, not separate games.
    filtered: list[Candidate] = []
    for item in candidates:
        if (item.path.parent, item.path.name.casefold()) in referenced_companions:
            ignored += 1
            continue
        if item.platform == "PS1" and item.path.suffix.casefold() in {".bin", ".img", ".mdf"}:
            item.reasons.append("Disc data file is not referenced by a discovered descriptor; verify it is a standalone image.")
        filtered.append(item)

    groups: dict[tuple[str, str], list[Candidate]] = defaultdict(list)
    for item in filtered:
        key_title = item.identity_title or item.path.stem.casefold()
        groups[(item.platform, key_title)].append(item)

    games = []
    uncertainties = []
    for (platform, identity), items in sorted(groups.items()):
        items.sort(key=lambda i: (i.disc or 0, i.relative_path.casefold()))
        display_title = min((i.title for i in items), key=lambda value: (len(value), value.casefold()))
        regions = sorted({i.region for i in items if i.region})
        game_id = hashlib.sha256(f"{platform}\0{identity}".encode("utf-8")).hexdigest()[:20]
        reasons = sorted({reason for i in items for reason in i.reasons})
        # Same title and disc occurring more than once is a duplicate representation/location.
        disc_counts = Counter(i.disc for i in items)
        if len(items) > 1 and any(count > 1 for count in disc_counts.values()):
            reasons.append("Duplicate title or alternate representation detected; all locations were retained.")
        files = [
            {
                "relativePath": i.relative_path,
                "filename": i.path.name,
                "kind": i.kind,
                **({"disc": i.disc} if i.disc is not None else {}),
            }
            for i in items
        ]
        game = {
            "id": game_id,
            "title": display_title,
            "normalizedTitle": identity,
            "platform": platform,
            "region": regions[0] if len(regions) == 1 else None,
            "files": files,
            "reviewRequired": bool(reasons),
        }
        if len(regions) > 1:
            game["regions"] = regions
        if reasons:
            game["reviewReasons"] = reasons
            uncertainties.append({"gameId": game_id, "title": display_title, "platform": platform, "reasons": reasons})
        games.append(game)

    platform_counts = dict(sorted(Counter(game["platform"] for game in games).items()))
    return {
        "format": SCHEMA_FORMAT,
        "version": SCHEMA_VERSION,
        "generatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "generator": {"name": "Checkpoint Scanner", "version": SCANNER_VERSION},
        "scan": {
            "selectedFolderName": root_path.name or root_path.drive or str(root_path),
            "readOnly": True,
            "filesVisited": visited_files,
            "filesIgnored": ignored,
            "gameCount": len(games),
            "platformCounts": platform_counts,
            "uncertainCount": len(uncertainties),
            "errorCount": len(issues),
        },
        "games": games,
        "uncertainties": uncertainties,
        "errors": issues,
    }


def export_inventory(inventory: dict, destination: str | Path) -> None:
    path = Path(destination)
    path.write_text(json.dumps(inventory, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


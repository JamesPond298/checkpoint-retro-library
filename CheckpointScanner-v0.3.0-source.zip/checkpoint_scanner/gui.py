from __future__ import annotations

import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .scanner import ScanCancelled, export_inventory, scan_directory


class CheckpointScannerApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Checkpoint Scanner")
        self.geometry("980x650")
        self.minsize(820, 520)
        self.inventory: dict | None = None
        self.events: queue.Queue = queue.Queue()
        self.cancel_event = threading.Event()
        self.folder_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Choose your ROM directory to begin.")
        self.summary_var = tk.StringVar(value="No scan yet")
        self._build()
        self.after(100, self._poll_events)

    def _build(self) -> None:
        style = ttk.Style(self)
        if "vista" in style.theme_names():
            style.theme_use("vista")
        outer = ttk.Frame(self, padding=16)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Checkpoint Scanner", font=("Segoe UI", 20, "bold")).pack(anchor="w")
        ttk.Label(outer, text="Build a private inventory of ROM filenames. Game files are never changed or copied.").pack(anchor="w", pady=(2, 14))

        picker = ttk.Frame(outer)
        picker.pack(fill="x")
        ttk.Entry(picker, textvariable=self.folder_var).pack(side="left", fill="x", expand=True)
        ttk.Button(picker, text="Choose ROM Folder…", command=self._choose).pack(side="left", padx=(8, 0))
        self.scan_button = ttk.Button(picker, text="Scan", command=self._start_scan)
        self.scan_button.pack(side="left", padx=(8, 0))
        self.cancel_button = ttk.Button(picker, text="Cancel", command=self.cancel_event.set, state="disabled")
        self.cancel_button.pack(side="left", padx=(8, 0))

        ttk.Label(outer, textvariable=self.summary_var, font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(14, 5))
        self.progress = ttk.Progressbar(outer, mode="indeterminate")
        self.progress.pack(fill="x")

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True, pady=(12, 10))
        result_frame = ttk.Frame(notebook)
        uncertain_frame = ttk.Frame(notebook)
        error_frame = ttk.Frame(notebook)
        notebook.add(result_frame, text="Games")
        notebook.add(uncertain_frame, text="Needs Review")
        notebook.add(error_frame, text="Scan Issues")

        self.games_tree = self._tree(result_frame, ("title", "platform", "region", "files", "review"), (420, 90, 100, 60, 100))
        self.review_tree = self._tree(uncertain_frame, ("title", "platform", "reason"), (250, 90, 520))
        self.error_tree = self._tree(error_frame, ("path", "message"), (360, 520))

        bottom = ttk.Frame(outer)
        bottom.pack(fill="x")
        ttk.Label(bottom, textvariable=self.status_var).pack(side="left", fill="x", expand=True)
        self.export_button = ttk.Button(bottom, text="Export checkpoint-library.json…", command=self._export, state="disabled")
        self.export_button.pack(side="right")

    def _tree(self, parent, columns, widths):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        for column, width in zip(columns, widths):
            tree.heading(column, text=column.replace("_", " ").title())
            tree.column(column, width=width, minwidth=50)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        return tree

    def _choose(self) -> None:
        selected = filedialog.askdirectory(title="Choose the ROM directory on your SD card", mustexist=True)
        if selected:
            self.folder_var.set(selected)

    def _start_scan(self) -> None:
        folder = self.folder_var.get().strip()
        if not folder:
            messagebox.showinfo("Choose a folder", "Choose your SD card ROM directory first.")
            return
        self.cancel_event.clear()
        self.scan_button.configure(state="disabled")
        self.cancel_button.configure(state="normal")
        self.export_button.configure(state="disabled")
        self.progress.start(12)
        self.status_var.set("Scanning read-only…")
        threading.Thread(target=self._worker, args=(folder,), daemon=True).start()

    def _worker(self, folder: str) -> None:
        try:
            result = scan_directory(
                folder,
                progress=lambda count, path: self.events.put(("progress", count, path)),
                cancelled=self.cancel_event.is_set,
            )
            self.events.put(("done", result))
        except ScanCancelled:
            self.events.put(("cancelled",))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def _poll_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "progress":
                    self.status_var.set(f"Scanned {event[1]} files… {event[2]}")
                elif event[0] == "done":
                    self._show_result(event[1])
                elif event[0] == "cancelled":
                    self._finish_controls()
                    self.status_var.set("Scan cancelled. No files were changed.")
                elif event[0] == "error":
                    self._finish_controls()
                    messagebox.showerror("Scan failed", event[1])
                    self.status_var.set("Scan failed. No files were changed.")
        except queue.Empty:
            pass
        self.after(100, self._poll_events)

    def _finish_controls(self) -> None:
        self.progress.stop()
        self.scan_button.configure(state="normal")
        self.cancel_button.configure(state="disabled")

    def _show_result(self, inventory: dict) -> None:
        self._finish_controls()
        self.inventory = inventory
        for tree in (self.games_tree, self.review_tree, self.error_tree):
            tree.delete(*tree.get_children())
        for game in inventory["games"]:
            self.games_tree.insert("", "end", values=(game["title"], game["platform"], game.get("region") or "", len(game["files"]), "Yes" if game["reviewRequired"] else ""))
        for item in inventory["uncertainties"]:
            self.review_tree.insert("", "end", values=(item["title"], item["platform"], "; ".join(item["reasons"])))
        for item in inventory["errors"]:
            self.error_tree.insert("", "end", values=(item["path"], item["message"]))
        scan = inventory["scan"]
        systems = ", ".join(f"{key}: {value}" for key, value in scan["platformCounts"].items()) or "none"
        self.summary_var.set(f"{scan['gameCount']} games • {len(scan['platformCounts'])} consoles • {scan['uncertainCount']} need review • {scan['errorCount']} issues")
        self.status_var.set(f"Detected systems: {systems}")
        self.export_button.configure(state="normal")

    def _export(self) -> None:
        if not self.inventory:
            return
        destination = filedialog.asksaveasfilename(
            title="Export Checkpoint inventory",
            defaultextension=".json",
            initialfile="checkpoint-library.json",
            filetypes=(("JSON inventory", "*.json"), ("All files", "*.*")),
        )
        if destination:
            try:
                export_inventory(self.inventory, destination)
                self.status_var.set(f"Exported {Path(destination).name}")
                messagebox.showinfo("Export complete", "The inventory was exported. No ROM contents were copied.")
            except OSError as exc:
                messagebox.showerror("Export failed", str(exc))


def main() -> None:
    CheckpointScannerApp().mainloop()


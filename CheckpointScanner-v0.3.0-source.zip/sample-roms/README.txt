Synthetic filename fixtures only. These text placeholders contain no ROM contents.


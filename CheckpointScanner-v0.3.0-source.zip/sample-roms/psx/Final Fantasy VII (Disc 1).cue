FILE "Final Fantasy VII (Disc 1) Track 01.bin" BINARY
  TRACK 01 MODE2/2352

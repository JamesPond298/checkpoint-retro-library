from pathlib import Path

from checkpoint_scanner.scanner import export_inventory, scan_directory

project = Path(__file__).resolve().parent
inventory = scan_directory(project / "sample-roms")
sample_output = project / "sample-output"
sample_output.mkdir(exist_ok=True)
export_inventory(inventory, sample_output / "checkpoint-library.json")
print(f"Wrote sample inventory with {inventory['scan']['gameCount']} games.")


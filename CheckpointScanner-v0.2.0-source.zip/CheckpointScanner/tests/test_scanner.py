import json
import tempfile
import unittest
from pathlib import Path

from checkpoint_scanner.scanner import export_inventory, scan_directory


class ScannerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "ROMS"
        self.root.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def touch(self, relative, text="synthetic test placeholder"):
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path

    def test_console_detection_ignore_and_grouping(self):
        self.touch("gba/Pokemon - FireRed Version (USA).gba")
        self.touch("SNES/Super Mario World (USA).sfc")
        self.touch("snes/saves/Super Mario World.srm")
        self.touch("psx/Final Fantasy VII (Disc 1).cue", 'FILE "Final Fantasy VII (Disc 1) Track 01.bin" BINARY\n')
        self.touch("psx/Final Fantasy VII (Disc 1) Track 01.bin")
        self.touch("psx/Final Fantasy VII (Disc 2).chd")
        result = scan_directory(self.root)
        self.assertEqual(result["scan"]["gameCount"], 3)
        ff7 = next(game for game in result["games"] if game["platform"] == "PS1")
        self.assertEqual(ff7["title"], "Final Fantasy VII")
        self.assertEqual(len(ff7["files"]), 2)
        self.assertEqual([f["disc"] for f in ff7["files"]], [1, 2])
        self.assertNotIn("Track 01.bin", json.dumps(result))

    def test_uncertain_zip_unmatched_bin_and_unknown_folder(self):
        self.touch("nes/Collection.zip")
        self.touch("ps1/Mystery.bin")
        self.touch("misc/Unknown Game.gba")
        result = scan_directory(self.root)
        self.assertEqual(result["scan"]["uncertainCount"], 2)
        self.assertEqual(result["scan"]["errorCount"], 1)

    def test_duplicate_locations_merge(self):
        self.touch("gba/set1/Metroid Zero Mission (USA).gba")
        self.touch("gba/set2/Metroid Zero Mission (USA).gba")
        result = scan_directory(self.root)
        self.assertEqual(result["scan"]["gameCount"], 1)
        self.assertEqual(len(result["games"][0]["files"]), 2)
        self.assertTrue(result["games"][0]["reviewRequired"])

    def test_sega_genesis_folder_support(self):
        self.touch("genesis/Sonic the Hedgehog 2 (USA).bin")
        result = scan_directory(self.root)
        self.assertEqual(result["scan"]["gameCount"], 1)
        self.assertEqual(result["games"][0]["platform"], "GENESIS")

    def test_export_is_versioned_and_has_relative_paths(self):
        self.touch("n64/Super Mario 64 (USA).z64")
        result = scan_directory(self.root)
        output = Path(self.temp.name) / "checkpoint-library.json"
        export_inventory(result, output)
        data = json.loads(output.read_text(encoding="utf-8"))
        self.assertEqual(data["format"], "checkpoint-inventory")
        self.assertEqual(data["version"], 1)
        self.assertEqual(data["games"][0]["files"][0]["relativePath"], "n64/Super Mario 64 (USA).z64")
        self.assertEqual(data["games"][0]["normalizedTitle"], "super mario 64")
        self.assertNotIn(str(self.root), output.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()


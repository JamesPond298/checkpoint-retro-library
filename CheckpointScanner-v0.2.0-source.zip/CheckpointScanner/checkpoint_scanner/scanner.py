from __future__ import annotations

import hashlib
import json
import os
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

SCHEMA_FORMAT = "checkpoint-inventory"
SCHEMA_VERSION = 1
SCANNER_VERSION = "0.2.0"

PLATFORMS = {
    "NES": ({"nes", "fc", "famicom"}, {".nes", ".zip"}),
    "SNES": ({"snes", "sfc", "supernintendo"}, {".sfc", ".smc", ".zip"}),
    "GB": ({"gb", "gameboy"}, {".gb", ".zip"}),
    "GBC": ({"gbc", "gameboycolor"}, {".gbc", ".zip"}),
    "GBA": ({"gba", "gameboyadvance"}, {".gba", ".zip"}),
    "N64": ({"n64", "nintendo64"}, {".z64", ".n64", ".v64", ".zip"}),
    "GENESIS": ({"genesis", "megadrive", "mega-drive", "md"}, {".md", ".gen", ".bin", ".zip"}),
    "NDS": ({"nds", "ds", "nintendods"}, {".nds", ".zip"}),
    "3DS": ({"3ds", "n3ds", "nintendo3ds"}, {".3ds", ".cci", ".cxi"}),
    "PS1": ({"psx", "ps1", "psone", "playstation"}, {".chd", ".cue", ".bin", ".pbp"}),
    "PSP": ({"psp", "playstationportable"}, {".iso", ".cso", ".chd"}),
}

IGNORED_DIRS = {
    "bios", "system", "saves", "save", "savestates", "states", "artwork",
    "images", "covers", "screenshots", "manuals", "bezels", "themes", "config",
    "configs", "metadata", "cache",
}

REGION_WORDS = {
    "usa": "USA", "us": "USA", "europe": "Europe", "eu": "Europe",
    "japan": "Japan", "jp": "Japan", "world": "World", "australia": "Australia",
}

REVIEW_TAGS = {"hack", "prototype", "proto", "beta", "demo", "translation", "homebrew", "unlicensed"}
DISC_RE = re.compile(r"(?i)(?:[\s._-]*[\[(]?(?:disc|disk|cd)\s*0*(\d+)[\])]?)")
TRACK_RE = re.compile(r"(?i)[\s._-]*(?:track|trk)\s*0*\d+")
BRACKET_RE = re.compile(r"\s*[\[(]([^\])]+)[\])]")


@dataclass
class Candidate:
    platform: str
    path: Path
    relative_path: str
    title: str
    identity_title: str
    region: str | None
    disc: int | None
    kind: str
    reasons: list[str] = field(default_factory=list)


class ScanCancelled(Exception):
    pass


def _compact(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.casefold())


ALIAS_TO_PLATFORM = {
    _compact(alias): platform
    for platform, (aliases, _extensions) in PLATFORMS.items()
    for alias in aliases
}


def platform_for_path(path: Path, root: Path) -> str | None:
    """Use the nearest recognized ancestor, including the selected directory."""
    try:
        parts = path.relative_to(root).parts[:-1]
    except ValueError:
        return None
    candidates = (root.name, *parts)
    for part in reversed(candidates):
        platform = ALIAS_TO_PLATFORM.get(_compact(part))
        if platform:
            return platform
    return None


def parse_name(stem: str) -> tuple[str, str, str | None, int | None, list[str]]:
    reasons: list[str] = []
    region = None
    disc_match = DISC_RE.search(stem)
    disc = int(disc_match.group(1)) if disc_match else None
    tags = [match.group(1).strip() for match in BRACKET_RE.finditer(stem)]
    for tag in tags:
        normalized = tag.casefold().strip()
        if normalized in REGION_WORDS and region is None:
            region = REGION_WORDS[normalized]
        if any(word in normalized for word in REVIEW_TAGS):
            reasons.append(f"Review filename tag: {tag}")
    title = DISC_RE.sub("", stem)
    title = TRACK_RE.sub("", title)
    title = BRACKET_RE.sub("", title)
    title = re.sub(r"(?i)\b(?:rev(?:ision)?\s*[a-z0-9.]+|v(?:er(?:sion)?)?\s*\d+(?:\.\d+)*)\b", "", title)
    title = re.sub(r"\s*[-_.]+\s*", " ", title)
    title = re.sub(r"\s+", " ", title).strip(" -_.") or stem
    identity = re.sub(r"[^a-z0-9]+", " ", title.casefold()).strip()
    return title, identity, region, disc, reasons


def _cue_references(path: Path) -> set[str]:
    refs: set[str] = set()
    try:
        text = path.read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return refs
    for match in re.finditer(r'(?im)^\s*FILE\s+(?:"([^"]+)"|(\S+))', text):
        refs.add(Path(match.group(1) or match.group(2)).name.casefold())
    return refs


def scan_directory(
    root: str | Path,
    progress: Callable[[int, str], None] | None = None,
    cancelled: Callable[[], bool] | None = None,
) -> dict:
    root_path = Path(root).expanduser().resolve()
    if not root_path.is_dir():
        raise ValueError("The selected ROM directory does not exist or is not a directory.")

    candidates: list[Candidate] = []
    issues: list[dict] = []
    ignored = 0
    referenced_bins: set[tuple[Path, str]] = set()
    visited_files = 0

    def on_walk_error(error: OSError) -> None:
        issues.append({"path": str(getattr(error, "filename", "")), "message": str(error)})

    for current, dirs, files in os.walk(root_path, topdown=True, onerror=on_walk_error, followlinks=False):
        if cancelled and cancelled():
            raise ScanCancelled()
        dirs[:] = [d for d in dirs if d.casefold() not in IGNORED_DIRS and not Path(current, d).is_symlink()]
        current_path = Path(current)
        for filename in files:
            visited_files += 1
            if progress and visited_files % 25 == 0:
                progress(visited_files, str(current_path))
            path = current_path / filename
            if path.is_symlink():
                ignored += 1
                continue
            platform = platform_for_path(path, root_path)
            ext = path.suffix.casefold()
            if not platform:
                if any(ext in extensions for _aliases, extensions in PLATFORMS.values()):
                    title, _identity, _region, _disc, _reasons = parse_name(path.stem)
                    issues.append({
                        "path": path.relative_to(root_path).as_posix(),
                        "message": f"Supported-looking file '{title}' is not inside a recognized console folder.",
                    })
                else:
                    ignored += 1
                continue
            allowed = PLATFORMS[platform][1]
            if ext not in allowed:
                ignored += 1
                continue
            reasons: list[str] = []
            if ext == ".zip":
                reasons.append("ZIP contents were not inspected; verify this archive contains one game.")
            if platform == "PS1" and ext == ".cue":
                refs = _cue_references(path)
                referenced_bins.update((path.parent, ref) for ref in refs)
                if not refs:
                    reasons.append("CUE file has no readable track references.")
            title, identity, region, disc, name_reasons = parse_name(path.stem)
            reasons.extend(name_reasons)
            kind = "disc-descriptor" if ext == ".cue" else "disc-image" if platform in {"PS1", "PSP"} else "rom"
            candidates.append(Candidate(
                platform, path, path.relative_to(root_path).as_posix(), title,
                identity, region, disc, kind, reasons,
            ))

    # A BIN referenced by a CUE is a track, not another game.
    filtered: list[Candidate] = []
    for item in candidates:
        if item.platform == "PS1" and item.path.suffix.casefold() == ".bin":
            if (item.path.parent, item.path.name.casefold()) in referenced_bins:
                ignored += 1
                continue
            item.reasons.append("BIN is not referenced by a discovered CUE file; verify it is a standalone disc image.")
        filtered.append(item)

    groups: dict[tuple[str, str], list[Candidate]] = defaultdict(list)
    for item in filtered:
        key_title = item.identity_title or item.path.stem.casefold()
        groups[(item.platform, key_title)].append(item)

    games = []
    uncertainties = []
    for (platform, identity), items in sorted(groups.items()):
        items.sort(key=lambda i: (i.disc or 0, i.relative_path.casefold()))
        display_title = min((i.title for i in items), key=lambda value: (len(value), value.casefold()))
        regions = sorted({i.region for i in items if i.region})
        game_id = hashlib.sha256(f"{platform}\0{identity}".encode("utf-8")).hexdigest()[:20]
        reasons = sorted({reason for i in items for reason in i.reasons})
        # Same title and disc occurring more than once is a duplicate representation/location.
        disc_counts = Counter(i.disc for i in items)
        if len(items) > 1 and any(count > 1 for count in disc_counts.values()):
            reasons.append("Duplicate title or alternate representation detected; all locations were retained.")
        files = [
            {
                "relativePath": i.relative_path,
                "filename": i.path.name,
                "kind": i.kind,
                **({"disc": i.disc} if i.disc is not None else {}),
            }
            for i in items
        ]
        game = {
            "id": game_id,
            "title": display_title,
            "normalizedTitle": identity,
            "platform": platform,
            "region": regions[0] if len(regions) == 1 else None,
            "files": files,
            "reviewRequired": bool(reasons),
        }
        if len(regions) > 1:
            game["regions"] = regions
        if reasons:
            game["reviewReasons"] = reasons
            uncertainties.append({"gameId": game_id, "title": display_title, "platform": platform, "reasons": reasons})
        games.append(game)

    platform_counts = dict(sorted(Counter(game["platform"] for game in games).items()))
    return {
        "format": SCHEMA_FORMAT,
        "version": SCHEMA_VERSION,
        "generatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "generator": {"name": "Checkpoint Scanner", "version": SCANNER_VERSION},
        "scan": {
            "selectedFolderName": root_path.name,
            "readOnly": True,
            "filesVisited": visited_files,
            "filesIgnored": ignored,
            "gameCount": len(games),
            "platformCounts": platform_counts,
            "uncertainCount": len(uncertainties),
            "errorCount": len(issues),
        },
        "games": games,
        "uncertainties": uncertainties,
        "errors": issues,
    }


def export_inventory(inventory: dict, destination: str | Path) -> None:
    path = Path(destination)
    path.write_text(json.dumps(inventory, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


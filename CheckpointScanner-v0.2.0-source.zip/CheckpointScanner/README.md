# Checkpoint Scanner for Windows 10/11

Checkpoint Scanner reads a console-organized ROM directory and exports a portable `checkpoint-library.json`. It records filenames and relative paths only. It never writes to, renames, moves, opens as ROM data, hashes, or copies game files.

## Run it

Requires Python 3.10 or newer (Python 3.12 tested).

1. Double-click `run_checkpoint_scanner.pyw`.
2. Choose the `ROMS` directory on the SD card, not necessarily the whole card.
3. Click **Scan**.
4. Review the **Games**, **Needs Review**, and **Scan Issues** tabs.
5. Click **Export checkpoint-library.json…** and save it wherever you want.

If Windows does not associate `.pyw` files with Python, open PowerShell in this folder and run:

```powershell
python -m checkpoint_scanner
```

## Supported folders and files

| Platform | Folder aliases | Extensions |
| --- | --- | --- |
| NES | `nes`, `fc`, `famicom` | `.nes`, `.zip` |
| SNES | `snes`, `sfc`, `supernintendo` | `.sfc`, `.smc`, `.zip` |
| Game Boy | `gb`, `gameboy` | `.gb`, `.zip` |
| Game Boy Color | `gbc`, `gameboycolor` | `.gbc`, `.zip` |
| Game Boy Advance | `gba`, `gameboyadvance` | `.gba`, `.zip` |
| Nintendo 64 | `n64`, `nintendo64` | `.z64`, `.n64`, `.v64`, `.zip` |
| Sega Genesis / Mega Drive | `genesis`, `megadrive`, `mega-drive`, `md` | `.md`, `.gen`, `.bin`, `.zip` |
| Nintendo DS | `nds`, `ds`, `nintendods` | `.nds`, `.zip` |
| Nintendo 3DS | `3ds`, `n3ds`, `nintendo3ds` | `.3ds`, `.cci`, `.cxi` |
| PlayStation | `psx`, `ps1`, `psone`, `playstation` | `.chd`, `.cue`, `.bin`, `.pbp` |
| PSP | `psp`, `playstationportable` | `.iso`, `.cso`, `.chd` |

Matching is case-insensitive and recursive. BIOS, save, state, artwork, cover, screenshot, manual, bezel, theme, config, metadata, and cache directories are skipped. Other unsupported file types are ignored.

### Review behavior

- A `.cue` plus its referenced `.bin` tracks becomes one disc entry; track files are not listed as games.
- Disc-number suffixes are removed from identity matching, so PS1 multi-disc titles group together.
- Duplicate title locations are retained under one game and flagged for review.
- ZIP files are flagged because version 0.1 does not inspect archive contents.
- Hacks, prototypes, betas, demos, translations, homebrew, and unlicensed filename tags are flagged.
- Supported-looking files outside a recognized console folder appear under **Scan Issues**.
- An unmatched PS1 BIN is retained but flagged instead of being silently discarded.

This version does filename parsing, not online catalog matching. A cleaned title is therefore a proposed identity and uncertain cases require review.

## Test it

```powershell
python -m unittest discover -s tests -v
```

The repository includes `sample-roms/`, a tiny synthetic folder tree containing text placeholders with ROM-like filenames. They are not game data. Regenerate the documented sample inventory with:

```powershell
python make_sample.py
```

## Build a standalone EXE

```powershell
python -m pip install pyinstaller
powershell -ExecutionPolicy Bypass -File .\build_exe.ps1
```

The executable will be `dist\Checkpoint-Scanner.exe`. PyInstaller is used only for packaging; the application itself uses the Python standard library.

## Inventory contract

The top level contains `format: "checkpoint-inventory"`, integer `version: 1`, generation metadata, scan counts, `games`, `uncertainties`, and non-fatal `errors`. Each game has a stable ID derived from platform plus normalized title, an explicit `normalizedTitle` matching hint, and one or more files with forward-slash relative paths. Absolute SD-card paths and ROM contents are excluded.

## Planned website handoff: series recommendations

The exported `title`, `normalizedTitle`, and `platform` fields are intended to feed Checkpoint's website catalog matcher. The website—not the read-only scanner—should own franchise knowledge and recommendation rules because a filename cannot reliably establish series order.

The planned recommendation flow is:

1. Match an imported game to a canonical catalog game ID, with manual review when confidence is low.
2. Link the canonical game to a franchise and an ordered subseries (release order and story order can differ).
3. Compare the ordered series against games the user owns and has completed.
4. Recommend missing earlier games, missing games between owned entries, or the next game after the latest completed entry.
5. Explain every suggestion, for example: “You own Final Fantasy III and IV; Final Fantasy I and II would complete the earlier numbered entries.”

Recommendations must remain separate from inventory records: an imported game means “detected on the card,” while a recommendation means “suggested for your backlog.” Users should be able to dismiss a suggestion, mark it as played elsewhere, choose release/story order, and exclude remakes or regional numbering variants. Final Fantasy in particular needs canonical catalog IDs because historic Japanese and international numbering does not always align.

